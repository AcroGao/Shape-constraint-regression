#########################
## Functions involving ##
#########################

# build B-spline basis based on input t vector
basis.func= function(t, nknots, norder)
{
  #nknots: number of interior knots
  #t: sample from U(0,1), size is n
  #norder: the order of B spine basis

  bound = c(min(t),max(t))

  breaks = seq(bound[1], bound[2], length=nknots+2) # build equal space knots input for creating B-splines

  bbasis = create.bspline.basis(bound, norder=norder, breaks=breaks) # use function to creat B-splines

  shift = 0.0001 # Sep-6th give right boundary a little shift such that we can use the left second derivative, which is a drawback of reference package( only right limit used without continuity)

  knots = c(bound[1], bbasis$params, bound[2]-shift) # all knots, including boundary (0,1)
                                                     # Need to evaluate the derivatives on these knots

  basis = eval.basis(t, bbasis) ###basis value at t location--worked as design matrix for splines coefficients

  dbasis = eval.basis(breaks, bbasis, 1) ### B'(knots)--in the constraint
                                         ### Since first derivative is continous, the use of breaks is fine

  ddbasis = eval.basis(knots, bbasis, 2) ### B''(knots)--in the constraint
                                         ### Second derivative need this shift adjustment for the last knot due to continuity

  return(list(basis=basis,dbasis=dbasis,ddbasis=ddbasis,knots=knots))
}

# apply quadratic programming to solve objective function with consdieration of the penalization
qp.func = function(basis, dbasis, ddbasis, lambda, weight, y)
{
  #basis: B-spline basis
  #dbasis: first derivative of basis at knots
  #ddbasis: second derivative of basis at knots
  #lambda: penalization parameter
  #w1.plus: adaptive weights for the positive part of the linear combination of first derivative
  #w1.minus: adaptive weights for the neg. part of the linear combination of first derivative
  #w2.plus: adaptive weights for the positive part of the linear combination of the second derivative
  #w2.minus: adaptive weights for the neg. part of the linear combination of the second derivative
  #y: response for design matrix(basis)

  N <- dim(basis)[2]    # number of basis

  kn <- N-1 # number of total knots (including 0 and 1)

  n <- dim(basis)[1]

  D <- cbind(basis,matrix(0, n, 4*kn)) # larger design matrix for the transformed parameters

  L <- diag(N+4*kn)
  diag(L)[1:N]=0

  v = 0.0001 #small term to make DTDnew positive definite (And smaller value may result Non-p.d.)
             #requirement of the quadratic programmming package input

  DTDnew <- t(D)%*%D + v*L

  D1 <- cbind(-dbasis, diag(kn), -diag(kn), matrix(0, kn, 2*kn))

  D2 <- cbind(-ddbasis, matrix(0, kn, 2*kn), diag(kn), -diag(kn))

  # Generate matrix A, this is A for two group constraints
  a1 <- diag(kn)
  a2 <- a1 %x% rep(1,kn)
  a3 <- rep(1,kn) %x% a1
  idx <- which(rowSums(abs(a3-a2))==0)
  A1A2 <- cbind(a2,a3)[-idx,]
  A3 <- cbind(A1A2, matrix(0, dim(A1A2)[1], 2*kn))
  A4 <- cbind(matrix(0, dim(A1A2)[1], 2*kn), A1A2)
  A5 <- rbind(A3, A4)
  A6 <- cbind(A5[,1:kn]*weight[1], A5[,(kn+1):(2*kn)]*weight[2], A5[,(2*kn+1):(3*kn)]*weight[3], A5[,(3*kn+1):(4*kn)]*weight[4])
  A <- cbind(matrix(0, dim(A6)[1], N), A6)

  C <- cbind(matrix(0, 4*kn, N), diag(4*kn))

  # Define G matrix
  G <- rbind(D1,D2,-A,C)

  ## Calculate beta.p under constraints and penalty using Quadratic Programming
  s <- lambda #lambda is a vector

  b0 <- c(rep(0,2*kn), -rep(s[1], kn*(kn-1)), -rep(s[2], kn*(kn-1)) , rep(0,4*kn))

  meq <- 2*kn

  alphah <- solve.QP(2*DTDnew,t(2*t(y)%*%D),t(G),b0,meq)

  Coef <- alphah$solution

  beta.p <- Coef[1:N] # First N is the estimator for coefficients of first N rows of alpha, which is beta

  return(beta.p)
}

# penalized method
PENreg = function(y, t, basis, dbasis, ddbasis, S, seedb, nknots, nboots)
{
  #(y,t): sample points
  #basis, dbasis, ddbasis: as in basis.func
  #S: tuning parameter grids
  #seedb: seed for bootstrap

  #estimation without penalty
  n = length(t)
  fit1 = lm(y ~ basis-1)
  yfit = fit1$fitted

  #Construct the adaptive penalty based on unpenalized estimation
  #Because boundary is not stable, thus we don't use the unpenalized value on boundary to estimate the weights
  gamma = dbasis%*%fit1$coef # first derivative at all knots including boundary (0,1)
  gammaint = gamma[-c(1,length(gamma)),] #get rid of the boundary (0,1)
  gamma.plus = gammaint*(gammaint>0)
  gamma.minus = -gammaint*(gammaint<0)
  delta = ddbasis%*%fit1$coef
  deltaint = delta[-c(1,length(delta)-1),]
  delta.plus = deltaint*(deltaint>0)
  delta.minus = -deltaint*(deltaint<0)
  wt1.plus = 1 / max(max(gamma.plus),0.001)
  wt1.minus = 1 / max(max(gamma.minus),0.001)
  wt2.plus = 1 / max(max(delta.plus),0.001)
  wt2.minus = 1 / max(max(delta.minus),0.001)
  weight <- c(wt1.plus, wt1.minus, wt2.plus, wt2.minus)

  #CIC-criterion initial input
  lambdas <- S  # select lambdas through each row of matrix S
  CM <- rep(0, dim(S)[1]) #save covariance matrix for each row
  RSS <- rep(0, dim(S)[1]) #save residual sum square for each row
  CIC <- rep(0, dim(S)[1]) #save CIC = RSS/n + 2CM/n for each row
  # GCV <- rep(0,dim(S)[1]) #save GCV for each row
  coef.cic = matrix(0,nknots+3,dim(S)[1]) # save estimated coef for each row, +3 beacuse we count two boundary and +1 for basis
  sigmasqh <- sum((y[2:n]-y[1:(n-1)])^2) / (2*(n-1)) #estimator for sigma-square based on "difference method"

  message("# Begin grid search for tuning parameter")
  message("# Total candidates amonut: ", dQuote(nrow(lambdas)) )
  timepercent = c(0.25, 0.5, 0.75) * nrow(lambdas)

  #Calculate CIC for each choice of S[i,] based on our penalized method
  for(k in 1:dim(lambdas)[1])
  {
    #print(k)
    if ( abs(k - timepercent[1]) < 0.49 ) {
      message("# 25% done")
    } else if (abs(k - timepercent[2]) < 0.49){
      message("# 50% done")
    } else if (abs(k - timepercent[3]) < 0.49){
      message("# 75% done")
    }

    lambda = lambdas[k,] #select one row of S to be restricted-value

    # RSS calculation through orginal fitted value
    beta.p <- try(qp.func(basis, dbasis, ddbasis, lambda, weight, y), silent = TRUE)
    # if not numeric return, report the warning!

    if(is.numeric(beta.p)) {
      coef.cic[,k] = beta.p # save resulted coefficients
      yfit.p = basis%*%beta.p
      RSS[k] = sum((y-yfit.p)^2)
      #RSS[k] = sum((fit0-yfit.p)^2)

      # CM calculation by paired bootstrap
      # save bootstrap fitted values
      nboot = nboots  # bootstrap times
      fit <- matrix(0,n,nboot) # save fitted value for each bootstrap penalty result, then used to calculate CIC
      ybs = NULL # save corresponding yi of penalty fitted above
      bootindex <- matrix(0,n,nboot) # storage matrix for the index of (yi,xi) in each bootstrap resampling
      for(b in 1:nboot){
        set.seed(seedb[b]) # set seed for boostrap resampling process
        index <- sample(1:n, n, replace = FALSE) # record resample points
        y.b = y[index]  # pick out the corresponding observed y value.
        t.b = t # generate corresponding t
        basis.b = basis  # pick out the corresponding basis value. same as basis.b = eval.basis(t.b, bbasis)
        ybs = cbind(ybs, y.b) # save each y.b in ybs
        fitb = lm(y.b~basis.b-1)  # calculate the coefficients for the bootstrap basis
        #fitb is the fitted process under bootstrap, without penalty, then used to calculate weight
        gammab = dbasis%*%fitb$coef
        gammabint = gammab[-c(1,length(gammab)),]
        gammab.plus = gammabint*(gammabint>0)
        gammab.minus = -gammabint*(gammabint<0)
        deltab = ddbasis%*%fitb$coef
        deltabint = deltab[-c(1,length(deltab)),]
        deltab.plus = deltabint*(deltabint>0)
        deltab.minus = -deltabint*(deltabint<0)
        wt1b.plus = 1 / max(max(gammab.plus),0.001)
        wt1b.minus = 1 / max(max(gammab.minus),0.001)
        wt2b.plus = 1 / max(max(deltab.plus),0.001)
        wt2b.minus = 1 / max(max(deltab.minus),0.001)
        weightb <- c(wt1b.plus, wt1b.minus, wt2b.plus, wt2b.minus)

        beta.b <- try(qp.func(basis.b, dbasis, ddbasis, lambda, weightb, y.b),silent = TRUE) #bootstrap estimation coefficient
        if(is.character(beta.b)) {
          beta.b <- rep(NA,dim(basis)[2])
        }
        # beta.b <- qp.func(basis.b, dbasis, ddbasis, lambda, weightb, y.b)
        yfit.b = basis%*%beta.b #original data's y values under bootstrap estimation
        fit[,b] <- yfit.b
        bootindex[,b] <- index
        # print(b)
      }

      missing <- which(is.na(fit[1,])==T)
      if( length(missing) !=0 ) {
        fit <- fit[,-missing]
        ybs <- ybs[,-missing]
      } else {
        fit <- fit
        ybs <- ybs
      }
      # Calculate CM through bootstrap results
      ybar <- apply(ybs,1,mean) # 1 for rows
      d <- ybs - ybar
      cov.b <- rep(0,n)
      for(i in 1:n){
        cov.b[i] <- t(fit[i,])%*%d[i,] / nboot
      }
      CM[k] <- sum(cov.b)

      # Calculate CIC by RSS and CM
      CIC[k] <- RSS[k]/n + CM[k]*2/n
      # GCV[k] <- RSS[k]/ ((n- CM[k]/ sigmasqh)^2)
    }

    if(is.character(beta.p)){
      RSS[k] <- NA
      CM[k] <- NA
      CIC[k] <- NA
    }
  }
  message("# Finish grid search for tuning parameter")

  s12.opt = lambdas[which.min(CIC),]
  coef.cic.opt = coef.cic[,which.min(CIC)]
  return(list(s12.opt=s12.opt, coef.cic.opt=coef.cic.opt, CIC=CIC, weight=weight, yfit=yfit)) # return optimal choice of lambda and
}

# Generating S.grid
genS.fun <- function(s.grid,l1,r1,l2,r2){
  s.1 <- seq(l1, r1, length = s.grid)
  s.2 <- seq(l2, r2, length = s.grid)
  S <- NULL
  for(i in 1:length(s.2)){
    a <- cbind(s.1,rep(s.2[i],length(s.2)))
    S <- rbind(S,a)
    colnames(S) <- c("s1", "s2")
  }
  return(S)
}

#############################
# Whole estimation function #
#############################
SCreg = function(data, nknots, ngrid, tps, seedb, nboots)
{
  require(fda)
  require(quadprog)
  require(MASS)
  require(methods)
  # data = data.sim, normalized data
  norder = 3
  time = ncol(data)
  l1 = tps[1]
  r1 = tps[2]
  l2 = tps[3]
  r2 = tps[4]
  S = genS.fun(ngrid,l1,r1,l2,r2) # range of tunning parameter is (0.1,2)
  first.der = rep(NA, nknots+2) # nknots, the number of internal knots.
  second.der = rep(NA, nknots+2)
  s12.opt = rep(NA, 2)
  coef.cic.opt = rep(NA, nknots+3)
  SCIC = cbind(S,rep(NA,dim(S)[1]))
  Sweight = rep(NA, 4)
  Sknots = rep(NA, nknots+2) # save knots (without 0,1) for simulations because no longer fixed knots, depend on quantile of t now
  datafpen = rep(NA, ncol(data)) # save to in proposed estimated y to plot
  datafupen = rep(NA, ncol(data)) # save to in proposed estimated y to plot

  t = data[1,]
  y = data[2,]

  basis.all = basis.func(t,nknots,norder)
  basis = basis.all$basis
  dbasis = basis.all$dbasis
  ddbasis = basis.all$ddbasis
  knots = basis.all$knots

  result = PENreg(y,t,basis,dbasis,ddbasis,S,seedb,nknots,nboots)

  upfit = as.numeric(result$yfit)

  datafupen = upfit

  pfit = as.numeric(basis%*%result$coef.cic.opt)

  datafpen = pfit # save to in proposed estimated y to plot

  # vector of difference in square
  first.der = dbasis%*%result$coef.cic.opt  # first derivative on knots

  second.der = ddbasis%*%result$coef.cic.opt # second derivative on knots, not continous, only use right limit, thus the shift used.

  s12.opt = result$s12.opt # choice of tunning parameter

  coef.cic.opt = result$coef.cic.opt

  SCIC[,3] = result$CIC

  Sweight = result$weight

  Sknots = knots

  return(list(  first.der=first.der,
                second.der= second.der,
                s12.opt=s12.opt,
                coef.cic.opt=coef.cic.opt,
                SCIC=SCIC,
                Sweight=Sweight,
                Sknots=Sknots,
                datafpen = datafpen,
                datafupen = datafupen))
}


